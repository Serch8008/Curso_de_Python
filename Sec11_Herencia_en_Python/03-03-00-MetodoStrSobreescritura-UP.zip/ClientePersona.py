from Persona import *

persona1 = Persona('Juan', 28)
print(persona1)

empleado1 = Empleado('Karla', 30, 5000)
print(empleado1)