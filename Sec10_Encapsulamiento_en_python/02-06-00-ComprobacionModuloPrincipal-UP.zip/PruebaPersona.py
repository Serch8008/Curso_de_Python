from Persona import Persona

if __name__ == '__main__':
    persona1 = Persona('Karla', 'Gomez', 30)
    persona1.mostrar_detalle()

    print(__name__)