from Persona import Persona

persona1 = Persona('Karla', 'Gomez', 30)
persona1.mostrar_detalle()